#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>

void trat(int s){
	char buff[60];
	sprintf(buff,"he recibido el signal \n");
	write(2,buff,strlen(buff));
}

main(){
	siginterrupt(SIGINT,1);
	signal(SIGINT,trat);
	char aux[60];
	char c;
	int res = read(0, &c, sizeof(char));
	if(res == -1){
		sprintf(aux,"Error de read\n");
		write(2,aux,strlen(aux));
	}else{
		sprintf(aux,"read correcto\n");
		write(2,aux,strlen(aux));
	}
	write(1, &c, sizeof(char));

}
