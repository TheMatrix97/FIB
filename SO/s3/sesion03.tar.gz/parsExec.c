#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void error_y_exit(char *msg, int exit_status){
	perror(msg);
	exit(exit_status);
 }
 
void muta_a_PS(char *parametro){
	execlp("./listaParametros", "./listaParametros", parametro, (char*) NULL);
	error_y_exit("ha fallado la mutacion", 1);
}

int main(int argc,char *argv[]){
	int i;
	for(i = 0; i < 4; ++i){
		int pid;
		pid = fork();
		if(pid == 0) muta_a_PS(argv[i]);
	}
	waitpid(0, NULL, -1);
			 
}
