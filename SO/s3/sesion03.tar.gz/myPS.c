#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include "dbg.h"


void error_y_exit(char *msg, int exit_status){
	perror(msg);
	exit(exit_status);
 }


void muta_a_PS(char *username){
	execlp("ps", "ps", "-u", username, (char*) NULL);
	error_y_exit("ha fallado la mutacion al ps", 1);
}


int main(int argc,char *argv[]){
	int pid;
	char *parametro = argv[1];
	char buffer[256];
	pid = fork();
	switch (pid){
		case 0:
			sprintf(buffer,"HIJO: Soy el proceso %d parametro=%s\n",getpid(),parametro);
			write(1,buffer,strlen(buffer));
			muta_a_PS(parametro);
			break;
			
		case -1:/* Se ha producido un error */
			strcpy(buffer,"Se ha prodcido une error\n");
			write(1, buffer, strlen(buffer));
			break;
			
		default:
			sprintf(buffer,"PADRE: Soy el proceso %d\n",getpid());
			write (1, buffer, strlen(buffer));
		
	}
	while(1);	
}
	
