#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>




void error_y_exit(char *msg, int exit_status){
	perror(msg);
	exit(exit_status);
 }


void muta_a_PS(char *username){
	execlp("ps", "ps", "-u", username, (char*) NULL);
	error_y_exit("ha fallado la mutacion al ps", 1);
}


int main(int argc,char *argv[]){
	int pid;
	int i;
	char buffer[256];
	sprintf(buffer,"soy el padre pid=%d", getpid());
	write(1,buffer,strlen(buffer));
	for(i = 1; i <= argc; ++i){
		pid = fork();
		if (pid == 0){
			muta_a_PS(argv[i]);
			exit(0);
		}
	}
	while (waitpid(-1, NULL, 0) > 0);
	char c;
	read(1,&c,sizeof(char));
}
	
