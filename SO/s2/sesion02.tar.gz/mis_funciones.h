
void error(char *c);
int esNumero (char *str);
int mi_atoi(char *s);
unsigned int char2int(char c);
void usage();

