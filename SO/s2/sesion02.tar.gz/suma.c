
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "mis_funciones.h"
#define MAX_SIZE 8

void main (int argc, char *argv[]){
  char buf[64];
  int i = 1;
  int fin = 1;
  while(i < argc && fin == 1){
	   fin = esNumero (argv[i]);
	   if(fin == 0) error(argv[i]);
	   else ++i;
  }
  if(fin != 0){
	  int suma = 0;
	  for(i = 1; i < argc; ++i) suma += mi_atoi(argv[i]);
	  sprintf(buf,"La suma es %i\n",suma);
	  write(1,buf,strlen(buf));
  }
}
