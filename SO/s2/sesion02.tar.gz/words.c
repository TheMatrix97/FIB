
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int contador(char *c){
	int i;
	int contador = 0;
	int size = strlen(c);
	for(i = 0; i < size; ++i){
		if(c[i] == ' '){
			++i;
			++contador;
		}
	}
	return contador + 1;
}
int main(int argc, char *argv[]){
	char *c = argv[1];
	int a = contador(c);
	char buff[256];
	sprintf(buff,"%i palabras",a);
	write(1,buff,strlen(buff));
}
