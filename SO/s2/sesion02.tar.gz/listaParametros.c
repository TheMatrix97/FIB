#include <stdio.h>
#include <string.h>
#include <unistd.h>

void usage(){
	char buff[256];
	char buff2[256];
	sprintf(buff, "Usage:listaParametros arg1 [arg2...argn] \n");
	sprintf(buff2, "Este programa escribe por su salida la lista de argumentos que recibe\n");
	write(1,buff, strlen(buff));
	write(1,buff2, strlen(buff2));
}
void main(int argc,char *argv[])
{
	char buf[80];
	int i;
	if(argc > 1){
		for (i=0;i<argc;i++){
			if (i==0){
				sprintf(buf,"El argumento %d es %s (es el nombre del ejecutable)\n",i,argv[i]);
			}else{
				sprintf(buf,"El argumento %d es %s\n",i,argv[i]);
			}
			write(1, buf, strlen(buf));
		}
	}
	else usage();
}
