#include "mis_funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

unsigned int char2int(char c){
	unsigned int val;
	if(c >= '0' && c <= '9') val = c - '0';
	return val;
}

int mi_atoi(char *s){
	int size = strlen(s);
	int val;
	int i;
	int neg = 0;
	if(s[0] == '-'){
		 i = 1;
		 neg = 1;
	}
	else i = 0;
	int first = 1;
	for(;i < size; ++i){
		int aux = char2int(s[i]);
		if(first == 1){
			val = aux;
			first = 0;
		}else val = val*10 + aux;
	}
	if(neg == 1)val = val * -1;
	return val;
}
int esNumero (char *str){
  int i = 0;
  int contador = 0;
  int negativo = 0;
  int no_esnum = 0;
  if (str != NULL){
      int size = strlen (str);
      while (i < size && no_esnum == 0){
		  if (i == 0 && str[i] == '-') negativo = 1;
		  else if (str[i] >= '0' && str[i] <= '9'){
			  ++contador;
			  if (contador > 8) no_esnum = 1;
		  }
		  else no_esnum = 1;
		  ++i;
	}
      if (no_esnum == 1) return 0;
      else return 1;
    }
  else return 0;
}
void error(char *c){
	char buff[256];
	sprintf(buff, "Error: el parametro '%s' no es un número\n",c);
	write(1,buff, strlen(buff));
}
void usage(){
	char buff[256];
	char buff2[256];
	sprintf(buff, "Usage:listaParametros arg1 [arg2...argn] \n");
	sprintf(buff2, "Este programa escribe por su salida la lista de argumentos que recibe\n");
	write(1,buff, strlen(buff));
	write(1,buff2, strlen(buff2));
}
