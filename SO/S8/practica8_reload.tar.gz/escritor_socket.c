#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "socketMng.c"

char id = '1';

void main (int argc, char *argv[]){
	char buffer[64];
	int descriptor = clientConnection(&id);
	int ret = read(0,&buffer,sizeof(buffer));
	while(ret > 0){
		write(descriptor,buffer,ret);
		ret = read(0,&buffer,sizeof(buffer));
	}
	closeConnection(descriptor);
}
